const models = require("../model");

exports.mypage_index = (req, res) => {
    console.log('바보');
}